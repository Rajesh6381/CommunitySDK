//
//  ViewController.swift
//  CommunitySDK
//
//  Created by zoho on 07/02/24.
//

import UIKit
import ZohoDeskPortalKB
import ZohoDeskPlatformDataBridge
import ZohoDeskPlatformUIKit

class DetailScreen: ZBDetailProtocol {
    func initialize(onCompletion: @escaping ((ZohoDeskPlatformDataBridge.ZPIntializeProgress) -> Void)) {
    }
    
    func render(basedOn patternType: ZDPatternType) -> String? {
        ZDPatternType.default
    }
    
    func prepareData(of dataSourceType: ZBDataSourceType) -> [ZBDataItem] {
        print("Date prepared")
        switch dataSourceType {
        case .navigation(.getElement(let elements)):
            elements.forEach({
                if $0.key == "topNavigation" {
                    $0.value.plainString = "Top Navigation Bar"
                }
                else if $0.key == "bottomNavigation" {
                    $0.value.plainString = "Bottom Navigation Bar"
                }
            })
            return elements
        case .collapsingHeader(.getElement(let elements)):
            elements.forEach({
                if $0.key == "collapsingHeader" {
                    $0.value.plainString = "Collapse View"
                }
            })
            return elements
        case .floatingHeader(.getElement(let elements)):
            elements.forEach({
                if $0.key == "floatingHeader" {
                    $0.value.plainString = "Floating View"
                }
            })
            return elements
        case .search(.getElement(let elements)):
            elements.forEach({
                if $0.key == "search" {
                    $0.value.plainString = "search view"
                }
            })
            return elements
        case .container(.getElement(let elements)):
            elements.forEach({
                if $0.key == "container" {
                    $0.value.plainString = "Container view"
                }
            })
            return elements
        case .keyboardAccessory(ofType: .getElement(let elements)):
            elements.forEach({
                if $0.key == "keyboardAccessory" {
                    $0.value.plainString = "Keyboard Accessory"
                }
            })
            return elements
        case .fab(.getElement(let elements)):
            elements.forEach({
                if $0.key == "fab" {
                    $0.value.plainString = "Fab Button"
                }
            })
            return elements
        default:
            return []
        }
        
    }
    
    var performAction: (() -> ())?
    
    var navigationIdentifier: String = "firstScreen"
    
    
}
class Binder: ZDBinderProtcol{
    func getDetailDataSource(_ identifier: String) -> ZohoDeskPlatformDataBridge.ZBDetailProtocol? {
        print("Detail")
        return DetailScreen()
    }
    
    func getReplayDataSource(_ identifier: String) -> ZohoDeskPlatformDataBridge.ZBReplyProtocol? {
        return nil
    }
    
    func getListDataSource(_ identifier: String) -> ZohoDeskPlatformDataBridge.ZBListProtocol? {
        return nil
    }
    
    func getChatDataSource(_ identifier: String) -> ZohoDeskPlatformDataBridge.ZBChatProtocol? {
        return nil
    }
    
    func prepareBuilderJSONS(onCompletion: @escaping (([Data]) -> Void)) {
        var listData = [Data]()
        let jsonFiles = ["ListView"]
        jsonFiles.forEach({ fileName in
           guard let url = Bundle.main.url(forResource: fileName, withExtension: "json"), let data = try? Data(contentsOf: url) else{
                return
            }
            listData.append(data)
            print("Json Fetched")
            onCompletion(listData)
            
        }
        )
    }
}


class ViewController: UIViewController {

    override func viewDidLoad(){
        super.viewDidLoad()
    }
    
    @IBAction func ButtonTap(_ sender: Any) {
        ZDPortalKB.show()
    }
    
    @IBAction func platformView(_ sender: Any){
        
        ZDPBuilderSDK(initial: "firstScreen", includeBinder: Binder()) { controller in
            
            print(self.navigationController)
            
            self.navigationController?.pushViewController(controller, animated: true)
            
        }
    }
}





